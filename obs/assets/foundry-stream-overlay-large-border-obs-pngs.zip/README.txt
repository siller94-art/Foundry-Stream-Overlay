Standalone OBS PNG overlays based on the existing module frame design.
Only the border size was increased.

Canvas: 1920x1080
Top border: 24 px
Side borders: 28 px
Bottom border: 72 px (covers the normal Windows taskbar area when the overlay fills a 1920x1080 canvas)
Center remains transparent.

OBS: Sources > + > Image, choose a PNG, keep at 1920x1080, place above game/window capture.
